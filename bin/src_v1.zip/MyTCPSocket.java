import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MyTCPSocket {

	InetAddress hostAddrs;
	int hostPort;
	InetAddress destAddress;
	int destPort;
	DatagramSocket socket;
	int host_isn;
	int dest_isn;
	int segmentSize = 10000;// in bytes;

	MyTCPSocket(int port, InetAddress destIp, int destPort){
		hostPort = port;
		destAddress = destIp;
		this.destPort = destPort; 
		try {
			socket = new DatagramSocket(hostPort);
		} catch (SocketException e) {
			e.printStackTrace();
		}

		//intiating handshake
		System.out.println("started handshake");
		intiateHandshake();

	}

	MyTCPSocket(int port, InetAddress destIp, int destPort, int nohandshake){
		hostPort = port;
		destAddress = destIp;
		this.destPort = destPort; 
		try {
			socket = new DatagramSocket(hostPort);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	MyTCPSocket(int port){
		hostPort = port;
		try {
			socket = new DatagramSocket(hostPort);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	public void intiateHandshake(){
		System.out.println("send data 1");
		reply(1);
		listenHandshake(1);
		System.out.println("send data 2");
		reply(2);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void setHost_isn(int isn){
		host_isn = isn;
	}

	public void setDest_isn(int isn){
		dest_isn = isn;
	}


	//for intial handshake
	// handle codes
	// 1  means first time send 
	// 2 means replying frist time to server
	public void reply(int handle){
		byte[] sendData;
		DatagramPacket sendPacket;
		ByteArrayOutputStream byteSendStream;
		ObjectOutputStream objectSendStream;
		MyTCPPacket handShakePacket;
		try {
			switch(handle){
			case 1:
				Random rGenerator = new Random();
				host_isn = rGenerator.nextInt(10000);
				//my tcp packet with seqNum, synbit
				handShakePacket = new MyTCPPacket(host_isn,true);
				byteSendStream = new ByteArrayOutputStream(1000);
				objectSendStream = new ObjectOutputStream(new BufferedOutputStream(byteSendStream));
				objectSendStream.flush();
				objectSendStream.writeObject(handShakePacket);
				objectSendStream.flush();
				sendData = byteSendStream.toByteArray();
				sendPacket = new DatagramPacket(sendData,sendData.length,destAddress,destPort);
				socket.send(sendPacket);
				objectSendStream.close();
				byteSendStream.close();
				break;
			case 2:
				handShakePacket = new MyTCPPacket(host_isn,true,true,dest_isn+1);
				byteSendStream = new ByteArrayOutputStream(1000);
				objectSendStream = new ObjectOutputStream(new BufferedOutputStream(byteSendStream));
				objectSendStream.flush();
				objectSendStream.writeObject(handShakePacket);
				objectSendStream.flush();
				sendData = byteSendStream.toByteArray();
				sendPacket = new DatagramPacket(sendData,sendData.length,destAddress,destPort);
				socket.send(sendPacket);
				objectSendStream.close();
				byteSendStream.close();

				break;
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void listenHandshake(int handle){
		byte[] reqRecvData = new byte[1000];
		DatagramPacket recvPacket;
		ByteArrayInputStream byteRecvStream;
		ObjectInputStream objectRecvStream;
		boolean whileFlag = true;

		try {
			recvPacket = new DatagramPacket(reqRecvData,reqRecvData.length);

			while(whileFlag){
				socket.receive(recvPacket);

				byteRecvStream = new ByteArrayInputStream(reqRecvData);
				objectRecvStream = new ObjectInputStream(new BufferedInputStream(byteRecvStream));

				MyTCPPacket newPacket = (MyTCPPacket)objectRecvStream.readObject();

				switch(handle){
				case 1:
					if( newPacket.syn ){
						dest_isn = newPacket.getSeqNum();
						host_isn += 1;
						whileFlag = false;
					}
					break;
				case 2:
					if( newPacket.ack ){
						//no functionality needed in this module	
					}
					break;
				case 3:
					if( newPacket.syn && newPacket.ack){
						if( newPacket.getSeqNum() == dest_isn + 1){
							dest_isn += 1;
							host_isn += 1;
							whileFlag = false;
						}
					}
					break;
				}

			}	
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void send(MyTCPPacket dataPacket){
		int dataPointer = 0;// this will point to first data array index which is still need to send


		byte[] dataArray = new byte[segmentSize];

		MyTCPPacket newPacket = new MyTCPPacket();

		byte[] sendData;
		DatagramPacket sendPacket;
		ByteArrayOutputStream byteSendStream;
		ObjectOutputStream objectSendStream;

		try {
			while(dataPointer < dataPacket.data.length){
				if( dataPacket.data.length - dataPointer >= segmentSize){
					System.out.println("data size : " + dataPacket.data.length );
					dataArray  = Arrays.copyOfRange(dataPacket.data, dataPointer, dataPointer+segmentSize);
				}else{
					System.out.println("data size : " + dataPacket.data.length );
					dataArray = new byte[dataPacket.data.length - dataPointer];
					dataArray  = Arrays.copyOfRange(dataPacket.data, dataPointer, dataPacket.data.length);	
				}
				newPacket.data = dataArray;
				newPacket.setSeqNum(host_isn);
				newPacket.setAckNum(dest_isn);
				byteSendStream = new ByteArrayOutputStream(20000);
				objectSendStream = new ObjectOutputStream(new BufferedOutputStream(byteSendStream));
				objectSendStream.flush();
				objectSendStream.writeObject(newPacket);
				objectSendStream.flush();
				sendData = byteSendStream.toByteArray();
				sendPacket = new DatagramPacket(sendData,sendData.length,destAddress,destPort);
				socket.send(sendPacket);
				objectSendStream.close();
				System.out.println("sent : " + dataArray.length);
				dataPointer += segmentSize;
				Thread.sleep(1);
			}

			newPacket.data = new byte[0];
			newPacket.setSeqNum(host_isn);
			newPacket.setAckNum(dest_isn);
			newPacket.setFin();
			byteSendStream = new ByteArrayOutputStream(2000);
			objectSendStream = new ObjectOutputStream(new BufferedOutputStream(byteSendStream));
			objectSendStream.flush();
			objectSendStream.writeObject(newPacket);
			objectSendStream.flush();
			sendData = byteSendStream.toByteArray();
			sendPacket = new DatagramPacket(sendData,sendData.length,destAddress,destPort);
			socket.send(sendPacket);


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

	public MyTCPPacket listen(){
		ArrayList<Byte> byteArray = new ArrayList<Byte>();

		byte[] reqRecvData = new byte[20000];
		DatagramPacket recvPacket;
		ByteArrayInputStream byteRecvStream;
		ObjectInputStream objectRecvStream;
		recvPacket = new DatagramPacket(reqRecvData,reqRecvData.length);
		MyTCPPacket newRcvdPacket;
		try {
			do{
				System.out.println("Listening...");
				socket.receive(recvPacket);
				byteRecvStream = new ByteArrayInputStream(reqRecvData);
				objectRecvStream = new ObjectInputStream(new BufferedInputStream(byteRecvStream));
				newRcvdPacket = (MyTCPPacket)objectRecvStream.readObject();
				System.out.println("recvd size : " + newRcvdPacket.data.length);
				for(int i=0; i < newRcvdPacket.data.length; i++){
					byteArray.add(new Byte(newRcvdPacket.data[i]));
				}
				System.out.println(newRcvdPacket.fin);
			}while(!newRcvdPacket.fin);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		MyTCPPacket finalPacket = new MyTCPPacket();
		Byte[] newBytes = byteArray.toArray(new Byte[byteArray.size()]);
		finalPacket.data = new byte[newBytes.length];
		for(int i = 0 ; i < newBytes.length; i++){
			finalPacket.data[i] = newBytes[i].byteValue();
		}
		return finalPacket;
	}

}
