import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Server {

	MyTCPServerSocket myServerSocket;
	MyTCPSocket clientSocket;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Server myServer = new Server();		
		myServer.myServerSocket = new MyTCPServerSocket(6565);
		myServer.clientSocket = myServer.myServerSocket.accept();
		System.out.println("got client socket..");
		MyTCPPacket getRqstPacket;
		String s;

		getRqstPacket = myServer.clientSocket.listen();
		
		s = new String(getRqstPacket.data);
		System.out.println("Now sending filename : "+s);
		if( s.equals("sendfileName")){
			
			myServer.sendFileName(args[0]);
		}
		
		getRqstPacket = myServer.clientSocket.listen();
		s = new String(getRqstPacket.data);
		if( s.equals("sendfile")){
			myServer.sendFile(args[0]);
		}

	}

	void sendFile(String filename){
		Path path = Paths.get(filename);
		byte[] fileData = null;
		try {
			fileData = Files.readAllBytes(path);
		} catch (IOException e) {
			e.printStackTrace();
		}
		MyTCPPacket filePacket = new MyTCPPacket(fileData);
		clientSocket.send(filePacket);	
	}
	
	void sendFileName(String filename){
		byte[] fileNameBytes = filename.getBytes();
		MyTCPPacket rqstPacket = new MyTCPPacket(fileNameBytes);
		clientSocket.send(rqstPacket);
	}


}
