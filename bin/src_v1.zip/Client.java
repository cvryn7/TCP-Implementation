import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class Client {

	MyTCPSocket socket;

	public static void main(String[] args) {
		Client clnt = new Client();
		try {
			clnt.socket = new MyTCPSocket(6565,InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
			System.out.println("handshake done!!!");
		} catch (NumberFormatException e1) {
			e1.printStackTrace();
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}
		clnt.requestFile("sendfileName");
		MyTCPPacket rcvdPacket = clnt.socket.listen();
		String filename = new String(rcvdPacket.data);
		clnt.requestFile("sendfile");

		byte[] fileData = (clnt.socket.listen()).data;

		FileOutputStream fileOuputStream;
		try {
			fileOuputStream = new FileOutputStream("x"+filename);
			fileOuputStream.write(fileData);
			fileOuputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 


		/*BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int opt = 0;
		while(true){
			System.out.println("Enter option for action!");
			System.out.println("1. Retrieve list of files on server.");
			System.out.println("2. Enter the filename to download");
			System.out.println("3. Exit");
			try {
				opt = Integer.parseInt(br.readLine());
			} catch (NumberFormatException | IOException e) {
				System.out.println("Wrong Input! Try Again!");
				continue;
			}
			if( opt != 1 || opt != 2 || opt != 3){
				System.out.println("Wrong Input! Try Again!");
				continue;
			}
			break;
		}
		if( opt == 1 ){
			clnt.getListOfRemoteFiles();
		}*/
	}

	void requestFile(String rqstMsg){
		byte[] rqstBytes = rqstMsg.getBytes();
		MyTCPPacket rqstPacket = new MyTCPPacket(rqstBytes);
		socket.send(rqstPacket);
	}

	void getListOfRemoteFiles(){
		MyTCPPacket pckt;
	}

}
