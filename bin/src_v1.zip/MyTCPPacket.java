import java.io.Serializable;
import java.net.DatagramPacket;
import java.net.InetAddress;

public class MyTCPPacket implements Serializable {

	byte[] data;
	int seqNum;
	int ackNum;
	int headerLen;
	int recvWindow;
	int checkSum;
	boolean ack=false;
	boolean fin=false;
	boolean syn=false;
	
	MyTCPPacket(){
		
	}
	
	MyTCPPacket(int seqNum){
		this.seqNum = seqNum;
	}
	
	MyTCPPacket(int seqNum, boolean syn){
		this.seqNum = seqNum;
		this.syn = syn;
	}
	
	MyTCPPacket(int seqNum, boolean syn, boolean ack, int ackNum){
		this.seqNum = seqNum;
		this.syn = syn;
		this.ack = ack;
		this.ackNum = ackNum;
	}
	
	MyTCPPacket(int seqNum, boolean ack, int ackNum){
		this.seqNum = seqNum;
		this.ack = ack;
		this.ackNum = ackNum;
	}
	
	MyTCPPacket(byte[] data){
		
		this.data = data;
	}
	
/*	MyTCPPacket(byte[] data, int seqNum){
		this.data = data;
		this.seqNum = seqNum;
	}
	
	MyTCPPacket(byte[] data, int seqNum, int ackNum){
		this.data = data;
		this.ackNum = ackNum;
	}
	
	MyTCPPacket(byte[] data, int seqNum, int ackNum, int recvWindow){
		this.data = data;
		this.seqNum = seqNum;
		this.ackNum = ackNum;
		this.recvWindow = recvWindow;
	}
	
	MyTCPPacket(byte[] data, int seqNum, int ackNum, int recvWindow, int checkSum){
		this.data = data;
		this.seqNum = seqNum;
		this.ackNum = ackNum;
		this.recvWindow = recvWindow;																																																																																	this.checkSum = checkSum;
	}
	
	int findCheckSum(byte[] data){
		int checkSum=0;
		return checkSum;
	}*/
	
	public void setSyn(){
		syn = true;
	}
	
	public int getSeqNum(){
		return seqNum;
	}
	
	public void setSeqNum(int seqNum){
		this.seqNum = seqNum;
	}
	
	public void setAckNum(int ackNum){
		this.ackNum = ackNum;
	}
	
	public void setFin(){
		fin = true;
	}
	
}
